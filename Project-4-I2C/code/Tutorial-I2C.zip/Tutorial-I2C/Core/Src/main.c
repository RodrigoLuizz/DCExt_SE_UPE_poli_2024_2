/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "eth.h"
#include "i2c.h"
#include "memorymap.h"
#include "usart.h"
#include "usb_otg.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
// Definindo explicitamente para usar o snprintf
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* *
 * Esse deslocamento é necessário porque o protocolo I2C usa o endereço em 7 bits,
 * mas o código precisa do endereço em 8 bits para incluir o bit de leitura/escrita.
 * */
#define PCF8591_ADDRESS 0x48 << 1  // Endereço do PCF8591 no barramento I2C
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// Buffers
uint8_t uart_rx_buffer[11];    // Buffer para o comando recebido
uint8_t uart_tx_buffer[20];    // Buffer para a resposta enviada

// Variáveis dos Sensores
uint8_t ldr_sensor = 0;
uint8_t temperature_sensor = 0;
uint8_t potenciometer = 0;

// Variáveis de Dados
uint8_t analog_data[2]; // Buffer para receber dados I2C
uint8_t channel_requested = 0; // Canal solicitado para leitura

void PCF8591_ReadAnalog_IT(uint8_t channel) {
    uint8_t config_byte = 0x40 | (channel & 0x03);
    channel_requested = channel; // Define o canal solicitado
    // Envia o byte de configuração em modo de interrupção
    HAL_I2C_Master_Transmit_IT(&hi2c2, PCF8591_ADDRESS, &config_byte, sizeof(config_byte));
}

// Função para definir o valor do DAC no PCF8591
void Set_DAC_Value(uint8_t value) {
    uint8_t dac_command[2] = {0x40, value};  // Comando para o DAC seguido do valor
    HAL_I2C_Master_Transmit_IT(&hi2c2, PCF8591_ADDRESS, dac_command, sizeof(dac_command));
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ETH_Init();
  MX_USART3_UART_Init();
  MX_USB_OTG_FS_PCD_Init();
  MX_I2C2_Init();
  /* USER CODE BEGIN 2 */

  // Mensagem inicial para o terminal
  char start_msg[] = "Comandos suportados: Read_AIN0, Read_AIN1, Read_AIN3, Set_DAC_<valor>\n";
  HAL_UART_Transmit_IT(&huart3, (uint8_t*)start_msg, sizeof(start_msg) - 1);

  // Inicia recepção de dados em modo interrupção
  HAL_UART_Receive_IT(&huart3, uart_rx_buffer, sizeof(uart_rx_buffer));
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    // Atualiza os valores dos sensores
    PCF8591_ReadAnalog_IT(0); // Lê o canal 0 [LDR]
    HAL_Delay(500);

    PCF8591_ReadAnalog_IT(1); // Lê o canal 1 [TEMP]
    HAL_Delay(500);

    PCF8591_ReadAnalog_IT(3); // Lê o canal 3 [POT]
    HAL_Delay(500); // Delay de 500 ms

//    __NOP();
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.HSIState = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 24;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_3;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV1;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
// Função de Callback para receber comandos via UART
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART3) {  // Verifica se a interrupção veio da UART3
        // Processa o comando recebido
        if (strncmp((char*)uart_rx_buffer, "Read_AIN0", 9) == 0) {
            snprintf((char*)uart_tx_buffer, sizeof(uart_tx_buffer), "AIN0: %d\n", ldr_sensor);
        }
        else if (strncmp((char*)uart_rx_buffer, "Read_AIN1", 9) == 0) {
            snprintf((char*)uart_tx_buffer, sizeof(uart_tx_buffer), "AIN1: %d\n", temperature_sensor);
        }
        else if (strncmp((char*)uart_rx_buffer, "Read_AIN3", 9) == 0) {
            snprintf((char*)uart_tx_buffer, sizeof(uart_tx_buffer), "AIN3: %d\n", potenciometer);
        }
        else if (strstr((char*)uart_rx_buffer, "Set_DAC_") == uart_rx_buffer) {
            uint8_t value = atoi((char*)&uart_rx_buffer[8]);
            Set_DAC_Value(value);
            snprintf((char*)uart_tx_buffer, sizeof(uart_tx_buffer), "Valor do DAC: %d\n", value);
        }

//        else if (strncmp((char*)uart_rx_buffer, "Set_DAC_", 8) == 0) {
//            uint8_t value = atoi((char*)&uart_rx_buffer[8]);  // Pega o valor após "Set_DAC_"
//            Set_DAC_Value(value);
//            snprintf((char*)uart_tx_buffer, sizeof(uart_tx_buffer), "Valor do DAC: %d\n", value);
//        }
        else {
            snprintf((char*)uart_tx_buffer, sizeof(uart_tx_buffer), "Comando invalido\n");
        }

        // Envia a resposta
        HAL_UART_Transmit_IT(&huart3, uart_tx_buffer, sizeof(uart_tx_buffer));

        // Limpa o buffer de recepção
        memset(uart_rx_buffer, 0, sizeof(uart_rx_buffer));

        // Reinicia a recepção para novos comandos
        HAL_UART_Receive_IT(&huart3, uart_rx_buffer, sizeof(uart_rx_buffer));
    }

}



void HAL_I2C_MasterTxCpltCallback(I2C_HandleTypeDef *hi2c) {
    if (hi2c->Instance == I2C2) {
        // Inicia a recepção após a transmissão do byte de configuração
        HAL_I2C_Master_Receive_IT(&hi2c2, PCF8591_ADDRESS, analog_data, 2);
    }
}

void HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef *hi2c) {
    if (hi2c->Instance == I2C2) {
        // Atualiza o valor lido conforme o canal solicitado
        switch(channel_requested) {
            case 0:
                ldr_sensor = analog_data[1];
                break;
            case 1:
                temperature_sensor = analog_data[1];
                break;
            case 3:
                potenciometer = analog_data[1];
                break;
            default:
        }
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
//  __disable_irq();
  // Função de tratamento de erro
  while (1) {
      HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_0);
      HAL_Delay(250);
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
